import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, it } from "node:test";
import type { ProviderEvidenceEvent } from "../src/domain/provider-evidence.js";
import {
  redactSecrets,
  SqliteProviderEvidenceStore,
} from "../src/storage/sqlite-provider-evidence-store.js";

describe("ProjectX provider evidence store", () => {
  it("persists monotonic hashed evidence across reopen", () => {
    const directory = mkdtempSync(join(tmpdir(), "glitch-projectx-evidence-"));
    const path = join(directory, "evidence.sqlite");
    try {
      let store = new SqliteProviderEvidenceStore(path);
      const first = store.append({
        receivedUtc: "2026-07-21T12:00:00Z",
        providerTimestampUtc: "2026-07-21T11:59:59Z",
        source: "projectx_user_stream",
        eventType: "order",
        generation: 2,
        accountId: 101,
        contractId: "CON.F.US.MNQ.U26",
        providerEntityId: "9001",
        rawPayload: { id: 9001, customTag: "glt-test" },
        normalizedPayload: { id: 9001, side: 0, size: 1 },
      });
      assert.equal(first.sequence, 1);
      assert.match(first.payloadHash, /^[0-9a-f]{64}$/);
      store.close();

      store = new SqliteProviderEvidenceStore(path);
      const second = store.append({
        receivedUtc: "2026-07-21T12:00:01Z",
        providerTimestampUtc: "2026-07-21T12:00:01Z",
        source: "projectx_market_stream",
        eventType: "quote",
        generation: 2,
        accountId: null,
        contractId: "CON.F.US.MNQ.U26",
        providerEntityId: "CON.F.US.MNQ.U26",
        rawPayload: { lastPrice: 20_000 },
        normalizedPayload: {
          lastPrice: 20_000,
          bestBid: 19_999.75,
          bestAsk: 20_000.25,
        },
      });
      assert.equal(second.sequence, 2);
      assert.deepEqual(store.recent().map((event) => event.sequence), [1, 2]);
      assert.deepEqual(store.status(), {
        eventCount: 2,
        marketEventCount: 1,
        earliestSequence: 1,
        latestSequence: 2,
        latestReceivedUtc: "2026-07-21T12:00:01Z",
        marketEventRetention: 500_000,
        marketPruneInterval: 10_000,
        maximumMarketEventsBetweenPrunes: 509_999,
      });
      store.close();
    } finally {
      rmSync(directory, { recursive: true, force: true });
    }
  });

  it("prunes only high-frequency market evidence and preserves monotonic identity", () => {
    const store = new SqliteProviderEvidenceStore(":memory:", {
      marketEventRetention: 3,
      marketPruneInterval: 1,
    });
    const append = (
      source: "projectx_market_stream" | "projectx_user_stream" | "projectx_rest",
      eventType: string,
      second: number,
    ) => store.append({
      receivedUtc: `2026-07-21T12:00:0${second}Z`,
      providerTimestampUtc: null,
      source,
      eventType,
      generation: 1,
      accountId: source === "projectx_market_stream" ? null : 101,
      contractId: "MNQ",
      providerEntityId: `${eventType}-${second}`,
      rawPayload: { second },
      normalizedPayload: { second },
    });

    append("projectx_user_stream", "order", 0);
    append("projectx_market_stream", "quote", 1);
    append("projectx_market_stream", "trade", 2);
    append("projectx_rest", "positions_snapshot", 3);
    append("projectx_market_stream", "depth", 4);
    append("projectx_market_stream", "quote", 5);
    const latest = append("projectx_market_stream", "trade", 6);

    const events = store.recent();
    assert.deepEqual(events.map((event) => event.sequence), [1, 4, 5, 6, 7]);
    assert.deepEqual(
      events.filter((event) => event.source === "projectx_market_stream").map((event) => event.sequence),
      [5, 6, 7],
    );
    assert.equal(latest.sequence, 7);
    assert.deepEqual(store.status(), {
      eventCount: 5,
      marketEventCount: 3,
      earliestSequence: 1,
      latestSequence: 7,
      latestReceivedUtc: "2026-07-21T12:00:06Z",
      marketEventRetention: 3,
      marketPruneInterval: 1,
      maximumMarketEventsBetweenPrunes: 3,
    });
    store.close();
  });

  it("commits a batch atomically and keeps retention honest", () => {
    const store = new SqliteProviderEvidenceStore(":memory:", {
      marketEventRetention: 3,
      marketPruneInterval: 1,
    });
    const event = (
      source: ProviderEvidenceEvent["source"],
      eventType: string,
      second: number,
    ): ProviderEvidenceEvent => ({
      receivedUtc: `2026-07-21T12:00:0${second}Z`,
      providerTimestampUtc: null,
      source,
      eventType,
      generation: 1,
      accountId: source === "projectx_market_stream" ? null : 101,
      contractId: "MNQ",
      providerEntityId: `${eventType}-${second}`,
      rawPayload: { second },
      normalizedPayload: { second },
    });

    const stored = store.appendBatch([
      event("projectx_user_stream", "order", 0),
      event("projectx_market_stream", "quote", 1),
      event("projectx_market_stream", "depth", 2),
      event("projectx_market_stream", "quote", 3),
      event("projectx_market_stream", "trade", 4),
    ]);
    assert.deepEqual(stored.map((item) => item.sequence), [1, 2, 3, 4, 5]);
    assert.equal(store.status().marketEventCount, 3);

    const before = store.status();
    assert.throws(() => store.appendBatch([
      event("projectx_user_stream", "order", 5),
      { ...event("projectx_user_stream", "order", 6), source: "bogus" as ProviderEvidenceEvent["source"] },
    ]));
    assert.equal(store.status().eventCount, before.eventCount);
    assert.equal(store.status().latestSequence, before.latestSequence);
    store.close();
  });

  it("prunes stale market evidence immediately when reopening with a smaller limit", () => {
    const directory = mkdtempSync(join(tmpdir(), "glitch-projectx-evidence-reopen-"));
    const path = join(directory, "evidence.sqlite");
    try {
      let store = new SqliteProviderEvidenceStore(path, {
        marketEventRetention: 5,
        marketPruneInterval: 5,
      });
      for (let index = 0; index < 5; index += 1) {
        store.append({
          receivedUtc: `2026-07-21T12:00:0${index}Z`,
          providerTimestampUtc: null,
          source: "projectx_market_stream",
          eventType: "quote",
          generation: 1,
          accountId: null,
          contractId: "MNQ",
          providerEntityId: `quote-${index}`,
          rawPayload: { index },
          normalizedPayload: { index },
        });
      }
      store.close();

      store = new SqliteProviderEvidenceStore(path, {
        marketEventRetention: 2,
        marketPruneInterval: 1,
      });
      assert.deepEqual(store.recent().map((event) => event.sequence), [4, 5]);
      assert.equal(store.status().marketEventCount, 2);
      store.close();
    } finally {
      rmSync(directory, { recursive: true, force: true });
    }
  });

  it("redacts nested credential key variants before persistence", () => {
    const store = new SqliteProviderEvidenceStore(":memory:");
    const event = store.append({
      receivedUtc: "2026-07-21T12:00:00Z",
      providerTimestampUtc: null,
      source: "projectx_rest",
      eventType: "sanitization_fixture",
      generation: 1,
      accountId: null,
      contractId: null,
      providerEntityId: null,
      rawPayload: {
        token: "top-secret",
        accessToken: "access-secret",
        new_token: "renewed-secret",
        nested: {
          apiKey: "secret-key",
          authorization: "Bearer secret",
          providerCredential: "credential-secret",
          harmless: "kept",
        },
        list: [{ password: "hidden" }],
      },
      normalizedPayload: null,
    });
    const redacted = event.rawPayload as {
      token: string;
      accessToken: string;
      new_token: string;
      nested: {
        apiKey: string;
        authorization: string;
        providerCredential: string;
        harmless: string;
      };
      list: Array<{ password: string }>;
    };
    assert.equal(redacted.token, "[REDACTED]");
    assert.equal(redacted.accessToken, "[REDACTED]");
    assert.equal(redacted.new_token, "[REDACTED]");
    assert.equal(redacted.nested.apiKey, "[REDACTED]");
    assert.equal(redacted.nested.authorization, "[REDACTED]");
    assert.equal(redacted.nested.providerCredential, "[REDACTED]");
    assert.equal(redacted.nested.harmless, "kept");
    assert.equal(redacted.list[0]?.password, "[REDACTED]");
    store.close();
  });

  it("redacts credential keys in retained REST envelopes", () => {
    const store = new SqliteProviderEvidenceStore(":memory:");
    const event = store.append({
      receivedUtc: "2026-08-19T20:50:00Z",
      providerTimestampUtc: null,
      source: "projectx_rest",
      eventType: "accounts_snapshot",
      generation: 1,
      accountId: 101,
      contractId: null,
      providerEntityId: null,
      rawPayload: {
        success: true,
        errorCode: 0,
        errorMessage: null,
        token: "session-secret",
        accounts: [{ id: 101, name: "TEST" }],
      },
      normalizedPayload: [{ id: 101, name: "TEST" }],
    });
    const raw = event.rawPayload as { token: string; accounts: Array<{ id: number }> };
    assert.equal(raw.token, "[REDACTED]");
    assert.equal(raw.accounts[0]?.id, 101);
    assert.equal(store.query({ source: "projectx_rest", eventType: "accounts_snapshot" }).length, 1);
    store.close();
  });

  it("rejects unbounded evidence reads and invalid internal options", () => {
    const store = new SqliteProviderEvidenceStore(":memory:");
    assert.throws(() => store.recent(0), /provider_evidence_limit_invalid/);
    assert.throws(() => store.recent(1_001), /provider_evidence_limit_invalid/);
    store.close();
    assert.throws(
      () => new SqliteProviderEvidenceStore(":memory:", {
        marketEventRetention: 3,
        marketPruneInterval: 4,
      }),
      /market_prune_interval_exceeds_retention/,
    );
  });

  it("redacts objects without mutating the caller payload", () => {
    const input = { nested: { apiKey: "secret", safe: "value" } };
    const output = redactSecrets(input) as typeof input;
    assert.equal(output.nested.apiKey, "[REDACTED]");
    assert.equal(output.nested.safe, "value");
    assert.equal(input.nested.apiKey, "secret");
  });
});
