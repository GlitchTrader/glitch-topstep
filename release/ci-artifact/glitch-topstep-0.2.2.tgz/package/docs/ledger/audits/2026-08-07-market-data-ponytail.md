# Market-data path Ponytail audit

**Date:** 2026-08-07
**Scope:** SignalR market ingest -> venue-state -> order-flow rebuild -> data_quality -> decision packet -> gateway_mode / execution gates
**Authority:** `docs/ledger/ledger.json`
**Method:** end-to-end read of the live path; delete/keep decisions under Ponytail (YAGNI, root cause over secondary exception paths)

## Verdict

Authority split is sound: venue/freshness completeness gates exposure; DOM/tape stay cognition evidence. Recent BestBid/BestAsk prune and full-batch DOM ingest are root-cause fixes. Residual noise was leftovers from superseded skew/optional experiments plus write-only venue buffers. `sanitizeOrderFlowDepthAgainstQuote` is honest packet evidence against a 10s rebuild clock, not an execution gate.

## Flow (canonical)

1. Market SignalR -> parse -> evidence SQLite + `VenueStateStore` quote (live).
2. Order-flow service rebuilds tape/depth from evidence on a 10s timer.
3. `evaluateSnapshotDataQuality` merges structural `stateIssues` with quote/state age.
4. Packet publishes quality + optional depth notes; `resolveGatewayMode` / gates / risk re-check freshness.
5. `armed` requires complete fresh state; `degraded_armed` still permits EXIT.

## Keep (correct primary behaviour)

| Piece | Why |
|-------|-----|
| Full `parseDepthBatch` ingest | Collapsed batches dropped sibling BestBid/Ask - root cause of broken books. |
| `applyBestBid` / `applyBestAsk` pointer semantics | ProjectX Best* are BBO pointers, not additive ladder rows. |
| Crossed/locked -> `invalid_depth_geometry` | Do not publish usable imbalance from impossible books. |
| Depth unavailable -> `optional_issues`, not `state_complete` | Matches AUTHORITY: DOM does not veto exposure. |
| Quote skew <=5s -> age 0, no advisory | NTP jitter is not incompleteness. |
| Reconcile-in-flight grace for `account_state_stale` | Operational truth while REST cycle runs. |
| Packet-time depth vs live quote check | Rebuild lag vs live quote is real; publishing divergent imbalance is false evidence. |

## Leftovers cleaned

| Leftover | Action |
|----------|--------|
| `SnapshotDataQuality.optionalIssues` always empty after skew-as-fresh | Removed from quality evaluator; packet still owns `optional_issues` for depth. |
| Stale packet comment about mild quote clock skew | Corrected. |
| `resolveGatewayMode` / `buildExecutionGates` unused order-flow args | Dropped after quiet-tape doctrine. |
| `VenueStateStore` `trades` / `marketTrades` / `depth` write-only buffers | Removed; evidence SQLite remains the market source of truth. |
| Dead `armedGateReasons` else-branch for `quote_stale` | Removed; stale quote already fails `state_complete`. |

## Stop line

Do not reintroduce strategy-shaped depth/tape gates. Do not stack more packet-side DOM compensations on top of Best* semantics - if books are wrong again, fix ingest/reconstruction once.
